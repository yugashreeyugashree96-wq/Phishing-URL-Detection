# ScamShield 360 — Smart Scam Message Investigator

## Project description
ScamShield 360 is an educational Python prototype that inspects a user-pasted message for common scam indicators such as urgency, prize claims, requests for sensitive information, payment pressure, and basic URL red flags. It prints a risk score, matched indicators, and safety advice.

## Important limitation
This is a rule-based educational tool, not a verified fraud detector. It may produce false positives or miss scams. A low score does not prove that a message or URL is safe. Do not paste real passwords, OTPs, bank details, or private messages containing sensitive information.

## Technologies used
- Python 3
- Python standard library: `re`, `urllib.parse`, `datetime`

## Dataset
The first version does not require an external dataset; it uses transparent example rules. If the bootcamp specifically requires a dataset, add a reputable, appropriately licensed public dataset and document its exact source and license before claiming dataset-based evaluation.

## Setup
1. Install Python 3.10 or later.
2. Download `Yugashree_ScamShield360.py`.
3. Open a terminal in the folder containing the file.

## Run
```bash
python Yugashree_ScamShield360.py
```
No external dependencies are required, so `requirements.txt` is intentionally minimal.

## Example test message
`URGENT: Your account is blocked. Verify your account now and click here http://192.0.2.10/login`

Use only fictional/example messages for testing.

## Files
- `Yugashree_ScamShield360.py` — source code
- `requirements.txt` — dependencies
- `Yugashree_ProjectReport.docx` — project report

## Future improvements
- Add a labeled, licensed public dataset and report precision/recall.
- Add a simple user interface.
- Improve URL analysis with reputable threat-intelligence services, while protecting user privacy.
- Add multilingual message patterns and clearly document limitations.
