"""
ScamShield 360 — Smart Scam Message Investigator
Educational prototype. This tool flags suspicious indicators; it cannot prove a message is a scam.
Run: python Yugashree_ScamShield360.py
"""

import re
from urllib.parse import urlparse
from datetime import datetime

URGENT_PHRASES = [
    "act now", "urgent", "immediately", "within 24 hours", "account blocked",
    "account suspended", "verify now", "last warning", "limited time"
]
MONEY_OR_PRIZE = [
    "you won", "winner", "prize", "lottery", "cashback", "free gift",
    "claim reward", "investment return", "guaranteed profit"
]
CREDENTIAL_REQUESTS = [
    "password", "otp", "one time password", "pin", "cvv", "bank details",
    "login details", "verify your account"
]
PRESSURE_PHRASES = [
    "click here", "open this link", "send otp", "share your password",
    "pay processing fee", "pay now", "transfer money"
]

URL_RE = re.compile(r"(https?://[^\s<>'\"]+|www\.[^\s<>'\"]+)", re.IGNORECASE)

def extract_urls(text):
    return [u.rstrip(".,);!?]") for u in URL_RE.findall(text)]

def url_indicators(url):
    candidate = url if url.lower().startswith(("http://", "https://")) else "http://" + url
    try:
        parsed = urlparse(candidate)
        host = (parsed.hostname or "").lower()
    except ValueError:
        return ["A URL could not be parsed safely."]
    findings = []
    if parsed.scheme == "http":
        findings.append("Link uses HTTP rather than HTTPS.")
    if "@" in parsed.netloc:
        findings.append("URL contains an @ symbol, which can obscure the intended destination.")
    if host.startswith("xn--") or ".xn--" in host:
        findings.append("Domain contains an internationalized/punycode label; check it carefully.")
    if re.search(r"\d{1,3}(?:\.\d{1,3}){3}", host):
        findings.append("URL uses an IP address instead of a recognizable domain.")
    if host.count("-") >= 3:
        findings.append("Domain contains several hyphens.")
    if len(host) > 35:
        findings.append("Domain name is unusually long.")
    if len(parsed.path) > 60:
        findings.append("URL path is unusually long.")
    if not findings:
        findings.append("No basic URL red flag detected; this does NOT mean the link is safe.")
    return findings

def analyze_message(message):
    lower = message.lower()
    findings = []
    score = 0

    for phrase in URGENT_PHRASES:
        if phrase in lower:
            findings.append(f"Urgency/pressure wording: “{phrase}”.")
            score += 12
    for phrase in MONEY_OR_PRIZE:
        if phrase in lower:
            findings.append(f"Prize/money claim: “{phrase}”.")
            score += 18
    for phrase in CREDENTIAL_REQUESTS:
        if phrase in lower:
            findings.append(f"Sensitive information mentioned: “{phrase}”.")
            score += 20
    for phrase in PRESSURE_PHRASES:
        if phrase in lower:
            findings.append(f"Action/payment pressure: “{phrase}”.")
            score += 15

    urls = extract_urls(message)
    for url in urls:
        findings.append(f"URL found: {url}")
        for item in url_indicators(url):
            findings.append(f"URL check: {item}")
            if "red flag" in item.lower() or "http rather" in item.lower() or "ip address" in item.lower() or "several hyphens" in item.lower() or "unusually long" in item.lower():
                score += 10

    if re.search(r"\b(otp|cvv|password|pin)\b", lower):
        score += 10
    score = min(score, 100)

    if score >= 50:
        level = "HIGH"
        advice = "Do not click links, pay, or share OTP/password/bank details. Verify using the official app or a phone number you already trust."
    elif score >= 25:
        level = "MEDIUM"
        advice = "Pause and independently verify the sender and request before taking action."
    else:
        level = "LOW INDICATORS FOUND"
        advice = "No strong indicator was found by this basic checker. Stay cautious; a low score does not prove the message is genuine."

    if not findings:
        findings.append("No configured scam indicator matched this message.")
    return {"score": score, "level": level, "findings": findings, "advice": advice, "urls": urls}

def main():
    print("=" * 58)
    print("SCAMSHIELD 360 — SMART SCAM MESSAGE INVESTIGATOR")
    print("=" * 58)
    print("Educational prototype: results are indicators, not a guarantee.")
    print("Paste a message to inspect. Type EXIT to close.\n")
    while True:
        message = input("Message to analyze: ").strip()
        if message.lower() == "exit":
            print("Stay safe online!")
            break
        if not message:
            print("Please enter a message.\n")
            continue
        result = analyze_message(message)
        print("\n--- ANALYSIS REPORT ---")
        print(f"Risk score: {result['score']}/100")
        print(f"Risk level: {result['level']}")
        print("\nIndicators:")
        for item in result["findings"]:
            print(f" - {item}")
        print(f"\nSafety recommendation: {result['advice']}")
        print("Note: This prototype uses simple rules, not a verified fraud database.")
        print("-" * 58 + "\n")

if __name__ == "__main__":
    main()
